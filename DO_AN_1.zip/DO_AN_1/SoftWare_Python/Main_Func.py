import sys
import os
from PyQt5.QtCore import *
from PyQt5.QtGui import *
from PyQt5.QtWidgets import *
from clock import *
import datetime
import requests

from datetime import date

from canvas import *

os.system("pyuic5 -x Main_Scr.ui -o Main_Scr.py")
os.system("pyrcc5 -o Weather_Icon_rc.py Weather_Icon.qrc")
os.system("pyrcc5 -o Icon_rc.py Icon.qrc")


from Main_Scr import *
from style import *
from GUI_PyQt5_Func import *
from button_bot_func import *

Counter = 0

class Main_Screen(Ui_MainWindow):
	UserName = ""
	Y = [0, 0, 0, 0, 0, 0, 0, 0]
	PH = 7
	dPH = 1
	def __init__(self, mainwindow):
		self.setupUi(mainwindow)
		self.Top_stackedWidget.setCurrentWidget(self.Top_ControlPanel)
		self.Bot_stackedWidget.setCurrentWidget(self.Bot_ControlPanel)

		#=================== thời tiết và thời gian ================
		self.clock_time = Clock()
		self.Top_Ctrl_frame5_clock_widget.addWidget(self.clock_time)
		try:
			self.weather()
		except :
			Wifi_icon = QtGui.QIcon()
			Wifi_icon.addPixmap	(QtGui.QPixmap(":/Green_Icon/Icon_Green/wifi-off.svg"), QtGui.QIcon.Normal, QtGui.QIcon.Off)
			self.Wifi_btn.setIcon(Wifi_icon)
			print("rem")

		#===================== bể nước ============================
		self.Slider2_4.valueChanged.connect(self.Tank_Water_control)

		#===================== chart =====================

		#__________1
		self.Y_Air_Temperature = [0, 0, 0, 0, 0, 0, 0, 0]
		self.grafica_1 = Canvas_grafica(self.Y_Air_Temperature)
		self.Top_Para_frame1_body_chart_T_KK.addWidget(self.grafica_1)
		#__________2
		self.Y_Land_PH = [0, 0, 0, 0, 0, 0, 0, 0]
		self.grafica_2 = Canvas_grafica(self.Y_Land_PH)
		self.Top_Para_frame1_body_chart_PH.addWidget(self.grafica_2)
		#__________3
		self.Y_Air_char = [0, 0, 0, 0, 0, 0, 0, 0]
		self.grafica_3 = Canvas_grafica(self.Y_Air_char)
		self.Top_Para_frame1_body_chart_Do_Am_KK.addWidget(self.grafica_3)
		#__________4
		self.Y_Land_Char = [0, 0, 0, 0, 0, 0, 0, 0]
		self.grafica_4 = Canvas_grafica(self.Y_Land_Char)
		self.Top_Para_frame1_body_chart.addWidget(self.grafica_4)
		#__________5
		self.Y_Light = [0, 0, 0, 0, 0, 0, 0, 0]
		self.grafica_5 = Canvas_grafica(self.Y_Light)
		self.verticalLayout_90.addWidget(self.grafica_5)
		#__________6
		self.Y_Land_Temperature = [0, 0, 0, 0, 0, 0, 0, 0]
		self.grafica_6 = Canvas_grafica(self.Y_Land_Temperature)
		self.verticalLayout_89.addWidget(self.grafica_6)

		self.Menu_btn.clicked.connect      (lambda: UIFunctions.ToggleMenu (self, 50, 300))
		self.Control_btn.clicked.connect   (lambda: UIFunctions.Select_Menu(self, 1))
		self.Parameter_btn.clicked.connect (lambda: UIFunctions.Select_Menu(self, 2))
		self.Setting_btn.clicked.connect   (lambda: UIFunctions.Select_Menu(self, 3))
		self.Properties_btn.clicked.connect(lambda: UIFunctions.Select_Menu(self, 4))
		self.Slogan_OKE_btn.clicked.connect(lambda: UIFunctions.Change_slogan(self))


		#============================ min max =================================
		self.Slider2_2.valueChanged.connect(self.Change_min_max_Sprinker)
		self.Mist.valueChanged.connect(self.Change_min_max_Sprinker)
		self.Slider2_5.valueChanged.connect(self.Change_min_max_light)
		self.light.valueChanged.connect(self.Change_min_max_light)
		self.Fan_State.currentTextChanged.connect(self.laygiatri)

# ========================================================================== button ===============================================================================

		self.pushButton_25.clicked.connect(lambda: button_slider.io_Btn_25(self))

		self.Mist_Button.valueChanged.connect(lambda: button_slider.io_Mist(self))
		self.open_light_Button.valueChanged.connect(lambda: button_slider.io_Light(self))
		self.Roof.valueChanged.connect(lambda: button_slider.io_Roof(self))
		self.Sprinkers.valueChanged.connect(lambda: button_slider.io_Sprinkers(self))

		self.Slider1_2.valueChanged.connect(lambda: self.Set_PH())
		self.Slider2_3.valueChanged.connect(lambda: self.Set_dPH())
		self.Fan_control.sliderReleased.connect(lambda: self.SetFan())

		self.Timer_Start()

	def SetFan(self):
		val = self.Fan_control.value()
		value = """{"Fanning": {Value}}"""
		new_value = value.replace("{Value}", str(int(val)))
		requests.patch('https://remt-45345-default-rtdb.firebaseio.com/Devices/.json', new_value)

	def laygiatri(self):
		if self.Fan_State.currentText() == "Luôn bật":
			self.Fan_control.setProperty("value", 1)

		if self.Fan_State.currentText() == "Luôn tắt":
			self.Fan_control.setProperty("value", 0)

# ============================================================================ min max ==============================================================================

	def Set_PH(self):
		self.PH = self.Slider1_2.value()
		self.Slider_label1_13.setText(str(self.PH))

	def Set_dPH(self):
		self.dPH = self.Slider2_3.value()
		self.Slider_label1_14.setText("+-" + str(self.dPH))

	def Change_min_max_Sprinker(self):
		self.Slider_label1_12.setText(str(self.Slider2_2.value()) + "'")
		self.Mist.setMinimum(0)
		self.Mist.setMaximum(int(self.Slider2_2.value()))

		self.Slider_label1_20.setText(str(self.Mist.value()) + "'")
		print(self.Mist.value())

	def Change_min_max_light(self):
		self.Slider_label1_19.setText(str(self.Slider2_5.value()) + " Lumen")
		self.light.setMinimum(0)
		self.light.setMaximum(int(self.Slider2_5.value()))

		val = self.light.value()
		self.label_13.setText(str(val) + " Lumen")
		print("Lumen" + str(val))
		value = """{"Lamping": {Value}}"""
		new_value = value.replace("{Value}", str(int(val * 2.25)))
		requests.patch('https://remt-45345-default-rtdb.firebaseio.com/Devices/.json', new_value)

	def Tank_Water_control(self):
		value = self.Slider2_4.value()
		self.Slider_label1_16.setText(str(int(value)) + "L")

# #=========================================================================== TIMER =================================================================================

	def Timer_Start(self):
		self.timer_WH = QtCore.QTimer()
		self.timer_WH.start(1000)
		self.timer_WH.timeout.connect(self.timer_Wh)
		self.timer_fan = QtCore.QTimer()
		self.timer_fan.start(1)
		self.timer_fan.timeout.connect(lambda: BTN_Func.Fan_Timer_CallBack(self))
		self.timer_firebase = QtCore.QTimer()
		self.timer_firebase.start(5000)
		self.timer_firebase.timeout.connect(self.Firebase_CallBack)

	def Firebase_CallBack(self):
		try :
			link_requests = "https://remt-45345-default-rtdb.firebaseio.com"
			Requests_Devices = "/Devices/.json"
			self.firebase_Json_data = requests.get(link_requests + Requests_Devices).json()
			print("remt-45345-default-rtdb")
			print(self.firebase_Json_data)

		except :
			print("no wifi")

		#======================== nhiệt độ đất ================================

		try :
			self.Dat_Gauge_Temp_CallBack(float(self.firebase_Json_data["Land Temperature"]))

			self.firebase_Json_data["Land Temperature"]

			self.Y_Land_Temperature.pop(-1)
			self.update__Land_Temp = []
			self.update__Land_Temp.append(self.firebase_Json_data["Land Temperature"])
			self.Y_Land_Temperature = self.update__Land_Temp + self.Y_Land_Temperature
			# print("main_ scr = " + str(self.Y_Land_Temperature))
			for i in reversed(range(self.verticalLayout_89.count())):
				self.verticalLayout_89.itemAt(i).widget().setParent(None)

			self.grafica_6 = Canvas_grafica(self.Y_Land_Temperature)
			self.verticalLayout_89.addWidget(self.grafica_6)

			# ======================= nhiệt độ không khí ===========================

			print(self.firebase_Json_data["Air Temperature"])
			self.KK_Gauge_Temp_CallBack(float(self.firebase_Json_data["Air Temperature"]))

			self.Y_Air_Temperature.pop(-1)
			self.update_data = []
			self.update_data.append(self.firebase_Json_data["Air Temperature"])
			self.Y_Air_Temperature = self.update_data + self.Y_Air_Temperature
			for i in reversed(range(self.Top_Para_frame1_body_chart_T_KK.count())):
				self.Top_Para_frame1_body_chart_T_KK.itemAt(i).widget().setParent(None)

			self.grafica_1 = Canvas_grafica(self.Y_Air_Temperature)
			self.Top_Para_frame1_body_chart_T_KK.addWidget(self.grafica_1)

			#======================== Độ ẩm đất =================================

			print(self.firebase_Json_data["Land Humidity"])
			self.Dat_Gauge_Humi_CallBack(float(self.firebase_Json_data["Land Humidity"]))

			self.Y_Land_Char.pop(-1)
			self.update_data_Land_Char = []
			self.update_data_Land_Char.append(self.firebase_Json_data["Land Humidity"])
			self.Y_Land_Char = self.update_data_Land_Char + self.Y_Land_Char
			for i in reversed(range(self.Top_Para_frame1_body_chart.count())):
				self.Top_Para_frame1_body_chart.itemAt(i).widget().setParent(None)

			self.grafica_4 = Canvas_grafica(self.Y_Land_Char)
			self.Top_Para_frame1_body_chart.addWidget(self.grafica_4)

			#======================== Độ ẩm không khí =======================

			print(self.firebase_Json_data["Air Humidity"])
			self.KK_Gauge_Humi_CallBack(float(self.firebase_Json_data["Air Humidity"]))

			self.Y_Air_char.pop(-1)
			self.update_data_Air_Char = []
			self.update_data_Air_Char.append(self.firebase_Json_data["Air Humidity"])
			self.Y_Air_char = self.update_data_Air_Char + self.Y_Air_char
			for i in reversed(range(self.Top_Para_frame1_body_chart_Do_Am_KK.count())):
				self.Top_Para_frame1_body_chart_Do_Am_KK.itemAt(i).widget().setParent(None)

			self.grafica_3 = Canvas_grafica(self.Y_Air_char)
			self.Top_Para_frame1_body_chart_Do_Am_KK.addWidget(self.grafica_3)

			#================================= PH =========================================

			print(self.firebase_Json_data["Land PH"])
			self.Dat_Gauge_PH_CallBack(float(self.firebase_Json_data["Land PH"]))

			self.Y_Land_PH.pop(-1)
			self.update_data_Land_PH = []
			self.update_data_Land_PH.append(self.firebase_Json_data["Land PH"])
			self.Y_Land_PH = self.update_data_Land_PH + self.Y_Land_PH
			for i in reversed(range(self.Top_Para_frame1_body_chart_PH.count())):
				self.Top_Para_frame1_body_chart_PH.itemAt(i).widget().setParent(None)

			self.grafica_2 = Canvas_grafica(self.Y_Land_PH)
			self.Top_Para_frame1_body_chart_PH.addWidget(self.grafica_2)

			#================================== Light ====================================

			print(self.firebase_Json_data["Brightness"])
			self.Gauge_LUX_CallBack(float(self.firebase_Json_data["Brightness"]))

			self.Y_Light.pop(-1)
			self.update_data_Light = []
			self.update_data_Light.append(self.firebase_Json_data["Brightness"])
			self.Y_Light = self.update_data_Light + self.Y_Light
			# print("main_ scr = " + str(self.Y_Light))
			for i in reversed(range(self.verticalLayout_90.count())):
				self.verticalLayout_90.itemAt(i).widget().setParent(None)

			self.grafica_5 = Canvas_grafica(self.Y_Light)
			self.verticalLayout_90.addWidget(self.grafica_5)

			print("PH:" + str(self.PH) + "    dPH:" + str(self.dPH))
			if(float(self.firebase_Json_data["Land PH"]) > float(self.PH + self.dPH)):
				style = """background-color: rgb(255, 80, 0);
						border-radius: 61px;"""
				text_style = """color: qlineargradient(spread:pad, x1:0, y1:0, x2:0, y2:1, stop:0 rgba(0, 245, 0, 255), stop:1 rgba(0, 159, 0, 255));
						background-color: rgba(0, 0, 0, 0);"""
			elif(float(self.firebase_Json_data["Land PH"]) < float(self.PH - self.dPH)):
				style = """background-color: rgb(90, 0, 150);
						border-radius: 61px;"""
				text_style = """color: qlineargradient(spread:pad, x1:0, y1:0, x2:0, y2:1, stop:0 rgba(255, 255, 255, 255), stop:1 rgba(200, 200, 200, 255));
						background-color: rgba(0, 0, 0, 0);"""
			else:
				style = """background-color: rgb(245, 245, 245);
						border-radius: 61px;"""
				text_style = """color: qlineargradient(spread:pad, x1:0, y1:0, x2:0, y2:1, stop:0 rgba(0, 201, 0, 255), stop:1 rgba(25, 81, 36, 255));
						background-color: rgba(0, 0, 0, 0);"""
			self.frame_27.setStyleSheet(style)
			self.pushButton_13.setStyleSheet(text_style)
			self.pushButton_14.setStyleSheet(text_style)



			print(self.firebase_Json_data["Water Tank Level"])
			self.Gauge_Watertank_CallBack(float(self.firebase_Json_data["Water Tank Level"]))

		except:
			print()


#============================================================================ ĐẤT ==================================================================================
	def Dat_Gauge_Temp(self, value):
		styleSheet = """
			border-radius: 75px;
			background-color: qconicalgradient(cx:0.5, cy:0.5, angle:224.5, stop:0 rgba(245, 245, 245, 255), stop:{stop_val1} rgba(245, 245, 245, 255), stop:{stop_val2} rgba(0, 0, 0, 0));
		"""
		stop2 = str(value * -0.018725 + 1.18725)
		stop1 = str(value * -0.018725 + 1.18725 - 0.01)
		styleSheet = styleSheet.replace("{stop_val1}", stop1).replace("{stop_val2}", stop2)
		self.frame_6.setStyleSheet(styleSheet)

	def Dat_Gauge_Temp_CallBack(self, value):

		self.Dat_Gauge_Temp(float(value))
		_translate = QtCore.QCoreApplication.translate
		self.pushButton_10.setText(_translate("MainWindow", str(value) + "°C"))

	def Dat_Gauge_Humi(self, value):
		styleSheet = """
			border-radius: 75px;
			background-color: qconicalgradient(cx:0.5, cy:0.5, angle:224.5, stop:0 rgba(245, 245, 245, 255), stop:{stop_val1} rgba(245, 245, 245, 255), stop:{stop_val2} rgba(0, 0, 0, 0));
		"""
		stop2 = str(value * -0.00749 + 1)
		stop1 = str(value * -0.00749 + 1 - 0.01)
		styleSheet = styleSheet.replace("{stop_val1}", stop1).replace("{stop_val2}", stop2)
		self.frame_24.setStyleSheet(styleSheet)

	def Dat_Gauge_Humi_CallBack(self, value):
		self.Dat_Gauge_Humi(int(value))
		_translate = QtCore.QCoreApplication.translate
		self.pushButton_12.setText(_translate("MainWindow", str(value) + "%"))

	def Dat_Gauge_PH(self, value):
		styleSheet = """border-radius: 75px;
			background-color: qconicalgradient(cx:0.5, cy:0.5, angle:224.5, stop:0 rgba(245, 245, 245, 255), stop:{stop_val1} rgba(245, 245, 245, 255), stop:{stop_val2} rgba(0, 0, 0, 0));
"""
		stop2 = str(value * -0.0535 + 1)
		stop1 = str(value * -0.0535 + 1 - 0.01)
		styleSheet = styleSheet.replace("{stop_val1}", stop1).replace("{stop_val2}", stop2)
		self.frame_26.setStyleSheet(styleSheet)

	def Dat_Gauge_PH_CallBack(self, value):
		self.Dat_Gauge_PH(int(value))
		_translate = QtCore.QCoreApplication.translate
		self.pushButton_14.setText(_translate("MainWindow", str(value)))

# #============================================================================ Không khí ==================================================================================

	def KK_Gauge_Temp(self, value):
		styleSheet = """border-radius: 75px;
			background-color: qconicalgradient(cx:0.5, cy:0.5, angle:224.5, stop:0 rgba(245, 245, 245, 255), stop:{stop_val1} rgba(245, 245, 245, 255), stop:{stop_val2} rgba(0, 0, 0, 0));
"""
		stop2 = str(value * -0.00749 + 1)
		stop1 = str(value * -0.00749 + 1 - 0.01)

		styleSheet = styleSheet.replace("{stop_val1}", stop1).replace("{stop_val2}", stop2)
		self.frame_30.setStyleSheet(styleSheet)

	def KK_Gauge_Temp_CallBack(self, value):
		self.KK_Gauge_Temp(int(value))
		_translate = QtCore.QCoreApplication.translate
		self.pushButton_18.setText(_translate("MainWindow", str(value) + "°C"))

	def KK_Gauge_Humi(self, value):
		styleSheet = """border-radius: 75px;
			background-color: qconicalgradient(cx:0.5, cy:0.5, angle:224.5, stop:0 rgba(245, 245, 245, 255), stop:{stop_val1} rgba(245, 245, 245, 255), stop:{stop_val2} rgba(0, 0, 0, 0));
"""
		stop2 = str(value * -0.00749 + 1)
		stop1 = str(value * -0.00749 + 1 - 0.01)
		styleSheet = styleSheet.replace("{stop_val1}", stop1).replace("{stop_val2}", stop2)
		self.frame_32.setStyleSheet(styleSheet)

	def KK_Gauge_Humi_CallBack(self, value):
		self.KK_Gauge_Humi(int(value))
		_translate = QtCore.QCoreApplication.translate
		self.pushButton_20.setText(_translate("MainWindow", str(value) + "%"))

# #============================================================================ LUX ==================================================================================

	def Gauge_LUX(self, value):
		styleSheet = """border-radius: 75px;
			background-color: qconicalgradient(cx:0.5, cy:0.5, angle:224.5, stop:0 rgba(245, 245, 245, 255), stop:{stop_val1} rgba(245, 245, 245, 255), stop:{stop_val2} rgba(0, 0, 0, 0));
"""
		stop2 = str(value * -0.007485 + 1)
		stop1 = str(value * -0.007485 + 1 - 0.01)
		styleSheet = styleSheet.replace("{stop_val1}", stop1).replace("{stop_val2}", stop2)
		self.frame_28.setStyleSheet(styleSheet)

	def Gauge_LUX_CallBack(self, value):
		self.Gauge_LUX(int(value))
		_translate = QtCore.QCoreApplication.translate
		self.pushButton_16.setText(_translate("MainWindow", str(value) + "Lux"))

# #=========================================================================== WH =============================================================================================

	def Gauge_WH(self, value):
		styleSheet = """
			border-radius: 105px;
			background-color: qconicalgradient(cx:0.5, cy:0.5, angle:{STOP_1}, stop:0.995399 rgba(0, 0, 42, 0), stop:0.996435 rgba(255, 0, 0, 255), stop:0.998964 rgba(255, 0, 0, 255), stop:1 rgba(0, 0, 42, 0));
		"""
		progress = int(100-value)
		stop_1 = str(1.8*progress)
		styleSheet = styleSheet.replace("{STOP_1}", stop_1)
		self.Top_Ctrl_frame4_body_Wh_4.setStyleSheet(styleSheet)

	# def Gauge_WH_CallBack(self, value):
	# 	self.Gauge_WH(int(value))

	def timer_Wh(self):
		global Counter
		value_1 ="""<html><head/><body><p><span style=" font-size:16pt; color:#ff0000;">0 0 0 0 {VALUE_1}</span></p></body></html>"""
		value_2 ="""<html><head/><body><p><span style=" font-size:16pt; color:#ff0000;">0 0 0 {VALUE_1} {VALUE_2}</span></p></body></html>"""
		value_3 ="""<html><head/><body><p><span style=" font-size:16pt; color:#ff0000;">0 0 {VALUE_1} {VALUE_2} {VALUE_3}</span></p></body></html>"""
		value_4 ="""<html><head/><body><p><span style=" font-size:16pt; color:#ff0000;">0 {VALUE_1} {VALUE_2} {VALUE_3} {VALUE_4}</span></p></body></html>"""
		if Counter > 10000:
			Counter = 0
		Counter += 1
		if Counter < 10:
			newValue = value_1.replace("{VALUE_1}", str(Counter))
			self.Top_Ctrl_frame4_body_metter.setText(newValue)
		elif Counter >= 10 and Counter < 100:
			newValue = value_2.replace("{VALUE_1}", str(Counter//10)).replace("{VALUE_2}", str(Counter%10))
			self.Top_Ctrl_frame4_body_metter.setText(newValue)
		elif Counter >= 100 and Counter < 1000:
			newValue = value_3.replace("{VALUE_1}", str(Counter//100)).replace("{VALUE_2}", str(Counter//10%10)).replace("{VALUE_3}", str(Counter%10))
			self.Top_Ctrl_frame4_body_metter.setText(newValue)
		elif Counter >= 1000 and Counter < 10000:
			newValue = value_4.replace("{VALUE_1}", str(Counter//1000)).replace("{VALUE_2}", str(Counter//100%10)).replace("{VALUE_3}", str(Counter//10%10)).replace("{VALUE_4}", str(Counter%10))
			self.Top_Ctrl_frame4_body_metter.setText(newValue)
		elif Counter >= 10000 and Counter < 100000:
			newValue = value_4.replace("{VALUE_1}", str(Counter//10000)).replace("{VALUE_2}", str(Counter//1000%10)).replace("{VALUE_3}", str(Counter//100%10)).replace("{VALUE_4}", str(Counter//10%10)).replace("{VALUE_5}", str(Counter%10))
			self.Top_Ctrl_frame4_body_metter.setText(newValue)

		self.Gauge_WH(Counter)


# #=========================================================================================== thời tiết ================================================================================

	def weather(self):
		today = date.today()
		days=["T2","T3","T4","T5","T6","T7","CN"]
		dayNumber=today.weekday()
		print(days[dayNumber])

		_translate = QtCore.QCoreApplication.translate
		api_address='https://api.openweathermap.org/data/2.5/weather?lat=10.850145464871641&lon=106.7716601973813&appid=59e434bde2d8ff7f30cfdb363d79aa61&lang=vi'
		json_data = requests.get(api_address).json()
		format_add = json_data['main']

		T_weather = """<html><head/><body><p><span style=" font-size:18pt; color:#ff0808;">{VALUE}</span><span style=" font-size:18pt; color:#ff0808; vertical-align:super;">0</span><span style=" font-size:18pt; color:#ff0808;">C</span></p></body></html>"""
		Value_1 = str(int(format_add["temp"]-273))

		new_T_Weather = T_weather.replace("{VALUE}",Value_1)
		self.T_Weather_label.setText(new_T_Weather)

		#============================== thu ngay ===================================

		if dayNumber == 0:
			self.T2.setStyleSheet("background-color: rgb(0, 255, 255);\n"
"font: 12pt \"Nirmala UI\";")
			self.T2.setText(days[dayNumber])
			self.T3.setStyleSheet("background-color: rgb(0, 255, 255);\n"
"font: 12pt \"Nirmala UI\";")
			day = str(today.day) + "/" + str(today.month)
			self.T3.setText(day)


		elif dayNumber == 1:
			self.T3.setStyleSheet("background-color: rgb(0, 255, 255);\n"
"font: 12pt \"Nirmala UI\";")
			self.T3.setText(days[dayNumber])
			self.T4.setStyleSheet("background-color: rgb(0, 255, 255);\n"
"font: 12pt \"Nirmala UI\";")
			day = str(today.day) + "/" + str(today.month)
			self.T4.setText(day)

		elif dayNumber == 2:
			self.T4.setStyleSheet("background-color: rgb(0, 255, 255);\n"
"font: 12pt \"Nirmala UI\";")
			self.T4.setText(days[dayNumber])
			self.T5.setStyleSheet("background-color: rgb(0, 255, 255);\n"
"font: 12pt \"Nirmala UI\";")
			day = str(today.day) + "/" + str(today.month)
			self.T5.setText(day)


		elif dayNumber == 3:
			self.T5.setStyleSheet("background-color: rgb(0, 255, 255);\n"
"font: 12pt \"Nirmala UI\";")
			self.T5.setText(days[dayNumber])
			self.T6.setStyleSheet("background-color: rgb(0, 255, 255);\n"
"font: 12pt \"Nirmala UI\";")
			day = str(today.day) + "/" + str(today.month)
			self.T6.setText(day)


		elif dayNumber == 4:
			self.T6.setStyleSheet("background-color: rgb(0, 255, 255);\n"
"font: 12pt \"Nirmala UI\";")
			self.T6.setText(days[dayNumber])
			self.T7.setStyleSheet("background-color: rgb(0, 255, 255);\n"
"font: 12pt \"Nirmala UI\";")
			day = str(today.day) + "/" + str(today.month)
			self.T7.setText(day)

		elif dayNumber == 5:
			self.T7.setStyleSheet("background-color: rgb(0, 255, 255);\n"
"font: 12pt \"Nirmala UI\";")
			self.T7.setText(days[dayNumber])
			self.CN.setStyleSheet("background-color: rgb(0, 255, 255);\n"
"font: 12pt \"Nirmala UI\";")
			day = str(today.day) + "/" + str(today.month)
			self.CN.setText(day)


		elif dayNumber == 6:
			self.T7.setStyleSheet("background-color: rgb(0, 255, 255);\n"
"font: 12pt \"Nirmala UI\";")
			self.T7.setText(days[dayNumber])
			self.CN.setStyleSheet("background-color: rgb(0, 255, 255);\n"
"font: 12pt \"Nirmala UI\";")
			day = str(today.day) + "/" + str(today.month)
			self.CN.setText(day)

		#============================== Thoi tiet ==================================


		if json_data['weather'][0]['main'] == 'Rain':
			icon = QtGui.QIcon()
			icon.addPixmap(QtGui.QPixmap(":/Weather/animated/rainy-7.svg"), QtGui.QIcon.Normal, QtGui.QIcon.Off)
			self.pushButton_3.setIcon(icon)
			text_do_am = """<html><head/><body><p><span style=" font-size:18pt; color:#3ec5ff;">{VALUE_D}%</span></p></body></html>"""
			new_text_do_am = text_do_am.replace("{VALUE_D}",str(format_add["humidity"]))
			self.pushButton_3.setIcon(icon)
			self.T_Do_Am_label_2.setText(new_text_do_am)
			self.pushButton_6.setText(_translate("MainWindow", "Trời đang mưa"))

		elif json_data['weather'][0]['main'] == 'Thunderstorm':
			text_do_am = """<html><head/><body><p><span style=" font-size:18pt; color:#3ec5ff;">{VALUE_D}%</span></p></body></html>"""
			new_text_do_am = text_do_am.replace("{VALUE_D}",str(format_add["humidity"]))
			icon = QtGui.QIcon()
			icon.addPixmap(QtGui.QPixmap(":/Weather/animated/thunder.svg"), QtGui.QIcon.Normal, QtGui.QIcon.Off)
			self.pushButton_3.setIcon(icon)
			self.T_Do_Am_label_2.setText(new_text_do_am)
			self.pushButton_6.setText(_translate("MainWindow", "Giông gió nhiều sét"))


		elif json_data['weather'][0]['main'] == 'Clouds':
			text_do_am = """<html><head/><body><p><span style=" font-size:18pt; color:#3ec5ff;">{VALUE_D}%</span></p></body></html>"""
			new_text_do_am = text_do_am.replace("{VALUE_D}",str(format_add["humidity"]))
			icon = QtGui.QIcon()
			icon.addPixmap(QtGui.QPixmap(":/Weather/animated/cloudy.svg"), QtGui.QIcon.Normal, QtGui.QIcon.Off)
			self.pushButton_3.setIcon(icon)
			self.T_Do_Am_label_2.setText(new_text_do_am)
			self.pushButton_6.setText(_translate("MainWindow", "Trời nhiều mây"))
		#print(json_data)
		print("Thời Tiết hiện tại: {0} Nhiệt độ thấp nhất là {1} Nhiệt độ cao nhất là {2} Độ C".format(
		json_data['weather'][0]['main'],float(format_add['temp_min']-273),float(format_add['temp_max']-273)))

		#============================================ Bể nước ====================================================
	def  Gauge_Watertank(self, value):
		self.label_10.setGeometry(QtCore.QRect(90, 0, 140, int(value)))

	def Gauge_Watertank_CallBack(self, value):
		self.Gauge_WH(int(value))
		temp_Water_Tank = 100 - 0.7142857*int(value)
		self.pushButton_25.setText(str(value) + "%")
		self.Gauge_Watertank(int(temp_Water_Tank))
