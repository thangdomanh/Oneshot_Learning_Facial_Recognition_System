import cv2
from facenet_pytorch import MTCNN
import torch
from datetime import datetime
import os
import numpy as np
import dill

device =  torch.device('cuda:0' if torch.cuda.is_available() else 'cpu')
print(device)

def visualize(input, faces, fps, thickness=2):
    if isSuccess:
        boxes, _, points_list = mtcnn.detect(input, landmarks=True)
        if boxes is not None:
            for box in boxes:
                bbox = list(map(int,box.tolist()))
                cv2.rectangle(input,(bbox[0],bbox[1]),(bbox[2],bbox[3]),(0,0,255),6)
    cv2.putText(input, 'FPS: {:.2f}'.format(fps), (1, 16), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 255, 0), 2)


IMG_PATH = './data/test_images/'
count = 2
with open('data1.dill', 'rb') as f:
    result_dict = dill.load(f)
usr_name = result_dict['names']
with open("data1.dill", "wb") as f:
    dill.dump({}, f)
USR_PATH = os.path.join(IMG_PATH, usr_name)
leap = 1

tm = cv2.TickMeter()

mtcnn = MTCNN(margin = 20, keep_all=False, select_largest = True, post_process=False, device = device)
cap = cv2.VideoCapture(0)
cap.set(cv2.CAP_PROP_FRAME_WIDTH,640)
cap.set(cv2.CAP_PROP_FRAME_HEIGHT,480)
while cap.isOpened() and count:
    isSuccess, frame = cap.read()
    tm.start()
    visualize(frame, isSuccess, tm.getFPS())
    tm.stop()
    if mtcnn(frame) is not None and leap%2:
        path = str(USR_PATH+'/{}.jpg'.format(str(datetime.now())[:-7].replace(":","-").replace(" ","-")+str(count)))      
        face_img = mtcnn(frame, save_path = path)
        count-=1
    leap+=1
    cv2.imshow('Face Capturing', frame)
    if cv2.waitKey(1)&0xFF == 27:
        break

    
cap.release()
cv2.destroyAllWindows()