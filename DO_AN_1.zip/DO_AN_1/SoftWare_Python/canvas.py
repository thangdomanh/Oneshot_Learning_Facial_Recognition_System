from matplotlib.backends.backend_qt5agg import FigureCanvasQTAgg as FigureCanvas
import matplotlib.pyplot as plt 
from Main_Func import *

class Canvas_grafica(FigureCanvas): 
	def __init__(self, Value_Y):

		self.fig , self.ax = plt.subplots(1, dpi=90, figsize=(1, 1), 
			sharey=True, facecolor='white') 
		super().__init__(self.fig)
		self.data_x = [1, 2, 3, 4, 5, 6, 7, 8] 
		self.a = [0, 0, 0, 0, 0, 0, 0, 0]

		for i in range(8):
			self.a[i] = int(Value_Y[i]) 

		self.ax.plot(self.data_x, self.a, marker = ".", markersize = 5) 
		self.remove_plot()

	def remove_plot(self):
		plt.close(self.fig) 

