
from PyQt5.QtCore import *
from PyQt5.QtGui import *
from PyQt5.QtWidgets import *
import os
import subprocess
import dill
import sys

os.system("pyuic5 -x Login_Scr.ui -o Login_Scr.py")

from Login_Scr import *

class Login_Main(Ui_MainWindow):
    show_mode = False

    def __init__(self, mainwindow):
        self.setupUi(mainwindow)
        mainwindow.setWindowFlags(QtCore.Qt.FramelessWindowHint) 
        mainwindow.setAttribute(QtCore.Qt.WA_TranslucentBackground)
        self.close_button.clicked.connect(lambda: self.close())
        self.BoxButton.clicked.connect(lambda: self.BoxButton_Show()) 
        self.eye.clicked.connect(lambda: self.eye_click())

        self.EnterButton.clicked.connect(lambda: self.scan_password())
        
        self.Create_account.clicked.connect(lambda: self.Create_acc()) 
        self.forgot_password.clicked.connect(lambda: self.Forgot_pass())
        self.comboBox.currentTextChanged.connect(self.laygiatri) 

    def  laygiatri(self): 
        self.User.setText(self.comboBox.currentText())

    def close(self): 
        sys.exit() 

    def BoxButton_Show(self):
        self.comboBox.showPopup()

    def scan_password(self): 
        User_scan = self.User.text()
        Password_scan = self.Password.text()
        return User_scan
        
    def Create_acc(self):
        
        result_dict = {'names': self.User.text()}
        with open('data1.dill', 'wb') as f:
            dill.dump(result_dict, f)
        if result_dict['names'] != '':
            process = subprocess.run(['python', 'c:/Users/THANG/Desktop/SoftWare_Python-20230508T123011Z-001/SoftWare_Python/face_capture.py'], stdout=subprocess.PIPE)
            process = subprocess.run(['python', 'c:/Users/THANG/Desktop/SoftWare_Python-20230508T123011Z-001/SoftWare_Python/update_faces.py'], stdout=subprocess.PIPE)

        self.label_5.setText("Nhập tên muốn tạo tại Tên đăng nhập.")
        self.label_5.setStyleSheet("color: rgba(255, 0, 0, 255);")
    def Forgot_pass(self):
        result_dict = {}
        process = subprocess.run(['python', 'c:/Users/THANG/Desktop/SoftWare_Python-20230508T123011Z-001/SoftWare_Python/face_recognition.py'], stdout=subprocess.PIPE)
        exec(process.stdout, result_dict)
        with open('data.dill', 'rb') as f:
            result_dict = dill.load(f)
        User_scan = result_dict['names']

        self.label_5.setText("OK.")
        self.label_5.setStyleSheet("color: rgba(255, 0, 0, 255);")
        return User_scan
    def eye_click(self): 
        eye_icon = QtGui.QIcon()
        if self.show_mode == False:
            self.show_mode = True
            self.Password.setEchoMode(QtWidgets.QLineEdit.Normal)
            eye_icon.addPixmap(QtGui.QPixmap(":/Green_Icon/Icon_Green/eye-off.svg"), QtGui.QIcon.Normal, QtGui.QIcon.Off)
            self.eye.setIcon(eye_icon)
        else :
            self.show_mode = False
            self.Password.setEchoMode(QtWidgets.QLineEdit.Password)
            eye_icon.addPixmap(QtGui.QPixmap(":/Green_Icon/Icon_Green/eye.svg"), QtGui.QIcon.Normal, QtGui.QIcon.Off)
            self.eye.setIcon(eye_icon) 