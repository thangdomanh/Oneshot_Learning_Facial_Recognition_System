from PyQt5.QtWidgets import QApplication, QMainWindow
from PyQt5.QtGui import*
from Login_Func import *
from Main_Func import *
import dill
import numpy as np
import sys

class UI: 
    def __init__(self) :
        self.login_uic = QtWidgets.QMainWindow()
        self.login = Login_Main(self.login_uic)
        self.login_uic.show()
        self.login.label_5.setText("")

        self.login.EnterButton.clicked.connect(lambda: self.changeUI("Main_Panel")) 
        self.login.forgot_password.clicked.connect(lambda: self.changeUI("Main_Panel")) 
        self.main_uic = QtWidgets.QMainWindow()
        self.main = Main_Screen(self.main_uic)
        self.main.Login_return.clicked.connect(lambda: self.changeUI("Login_Func"))   

    def changeUI(self, i):
        if i == "Main_Panel":
                User_scan = self.login.User.text()
                Password_scan = self.login.Password.text()
                _translate = QtCore.QCoreApplication.translate
                
                self.main.UserName = self.login.User.text()
                self.main.User_name.setText("%s"%self.main.UserName)
                
                if User_scan == "Đinh Thanh Tùng" and Password_scan == "1":
                    self.login_uic.hide()
                    self.main_uic.show()

                if User_scan == "Đỗ Mạnh Thắng" and Password_scan == "20139091":
                    self.login_uic.hide()
                    self.main_uic.show()               

                if User_scan == "Nguyễn Vũ Tú" and Password_scan == "3":
                    self.login_uic.hide()
                    self.main_uic.show()               
                    
                else:
                    with open('data.dill', 'rb') as f:
                        result_dict = dill.load(f)
                    User_scan=''
                    if 'names' in result_dict:
                            User_scan = result_dict['names']
                            User_scan = User_scan.item()
                            Password_scan = '7'
                            self.main.UserName = User_scan 
                            self.main.User_name.setText("%s"%self.main.UserName)
                    with open("data.dill", "wb") as f:
                            dill.dump({}, f)
                    if User_scan != '' and Password_scan == '7':
                            User_scan = ''
                            self.login_uic.hide()
                            self.main_uic.show()
                    else:
                            self.login.label_5.setText("Bạn nhập sai mật khẩu")
                            self.login.label_5.setStyleSheet("color: rgba(255, 0, 0, 255);")
            
        elif i == "Login_Func":
            self.main_uic.hide()
            self.login_uic.show()
            self.login.label_5.setText("")


if __name__ == "__main__":
    app = QtWidgets.QApplication(sys.argv)
    ui = UI()    
    app.exec_()