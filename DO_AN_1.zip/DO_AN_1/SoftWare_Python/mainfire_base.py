'''
Created on 28 thg 5, 2022

@author: A315-56
'''
from firebase import firebase

firebase = firebase.FirebaseApplication("https://remt-45345-default-rtdb.firebaseio.com", None)
# HÀM ĐÊ CẬP NHẬT DỮ LIỆU TỪ CODE PY LÊN FIREBASE (1 là bật, 0 là tắt).
# 1. Bật mái che.
firebase.patch('/Devices', {"Covering": 1})
# 2. Bật phun sương.
firebase.patch('/Devices', {"Mistting": 1})
# 3. Bật máy bơm.
firebase.patch('/Devices', {"Pumping": 1})
# 4. Bật tưới nước.
firebase.patch('/Devices', {"Watering": 1})
# 5. Đặt mức sáng của đèn.
firebase.patch('/Devices', {"Lamping": 128}) # Từ 0-255
# 6. Đặt số quạt.
firebase.patch('/Devices', {"Fanning": 1}) # 0, 1, 2, 3 ở đây ví dụ số 1 
# 7. Tắt mái che.
firebase.patch('/Devices', {"Covering": 0})
# 8. Tắt phun sương.
firebase.patch('/Devices', {"Mistting": 0})
# 9. Tắt máy bơm.
firebase.patch('/Devices', {"Pumping": 0})
# 10. Tắt tưới nước.
firebase.patch('/Devices', {"Watering": 0})
# 11. Cập nhật slogan.
firebase.patch('/Interface', {"Slogan": "Thời buổi 4.0 - Trồng rau với IoT. Đừng trồng rau"})
# 12. Đặt light theme.
firebase.patch('/Interface', {"Theme": 1})
# 13. Đặt dark theme.
firebase.patch('/Interface', {"Theme": 0})
# 14. Đặt 1 dàn (nhiều) giá trị 1 lúc.
# Ví dụ t bật phun sương, tắt tưới, bật mái che, bật máy bơm, đèn sáng mức 65, quạt chạy số 2.
firebase.patch('/Devices', {"Mistting": 1, "Watering": 0, "Covering": 1, "Pumping": 0, "Lamping": 65, "Fanning": 2})


# HÀM ĐÊ ĐỌC DỮ LIỆU TỪ FIREBASE
#Dạng tổng quát: firebase.get("/đường dẫn, ví dụ: "/Devices", "Environment parameter", ....", None)
# ví dụ lấy dữ liệu Interface
firebase.get("/Interface", None)
# dữ liệu lấy về dưới dạng dictionary.
# Xem hàm Firebase_CallBack trong file Main_Func.py để bt thêm chi tiết.




# import firebase_admin
# from firebase_admin import credentials
# from firebase_admin import db
#
# cred = credentials.Certificate("pygui-iot-7dfeb-firebase-adminsdk-l5zne-cf571a2d73.json")
# firebase_admin.initialize_app(cred, {"databaseURL": "https://pygui-iot-7dfeb-default-rtdb.firebaseio.com"})
#
#
# ref = db.reference("/")
# Enviroment = ref.child("Environment parameter")
# print("Start")
# print(Enviroment.update({'Air Humidity': 95, 'Air Temperature': 42, 'Brightness': 256, 'Land Humidity': 95, 'Land Temperature': 45, 'Water Tank Level': 55}))








